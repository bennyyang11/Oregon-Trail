#ifndef party_h
#define party_h
#include <string>
using namespace std;
class Party{
    public:
        Party();
        Party(string name, int age , string job , int count,int health);
        string getName();
        void setName(string name);
        int getCount();
        void setCount(int count);
        string getJob();
        void setJob(string job);
        int getAge();
        void setAge(int age);
        int getHealth();
        void setHealth(int health);
    private:
        string name;
        int count;
        string job;
        int count;
        int health;
};
#endif