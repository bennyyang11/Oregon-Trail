#ifndef player_h
#define player_h
#include <string>
using namespace std;
class Player{
    public:
        Player();
        Player(string name, int age, string job,int health);
        string getName();
        void setName(string name);
        int getAge();
        void setJob(int age);
        string getJob();
        void setJob(string job);
        int getHealth();
        void setHealth(int health);
    private:
        string name;
        int age;
        string job;
        int health;
};
#endif
