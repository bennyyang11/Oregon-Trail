#ifndef environment_h
#define environment_h
#include <string>
using namespace std;
class Environment{
    public:
        Environment();
        Environment(string weather, int temp, string Biome, string species);
        string getWeather();
        void setWitle(string weather);
        int getTemp();
        void setTemp(int temp);
        string getBiome();
        void setBiome(string Biome);
        string GetSpecies();
        void setSpeicies(string species);
    private:
        string weather;
        int temp;
        string Biome;
        string species;
};
#endif