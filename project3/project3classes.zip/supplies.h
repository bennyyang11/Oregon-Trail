#ifndef supplies_h
#define supplies_h
#include <string>
using namespace std;
class Supplies{
    public:
        Supplies();
        Supplies(string food, int count, string water, string clothes);
        string getFood();
        void setFood(string food);
        int getCount();
        void setCount(int count);
        string getWater();
        void setWater(string water);
        string getClothes();
        void setClothes(string clothes);
    private:
        string food;
        int count;
        string water;
        string clothes;
};
#endif